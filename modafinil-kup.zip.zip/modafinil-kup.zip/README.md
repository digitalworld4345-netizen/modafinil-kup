# Modafinil-kup.pl

E-commerce website for Modafinil products in Poland.

## How to Deploy

1. Upload to GitHub
2. Connect to Netlify
3. Add `EMAIL_PASS` in Netlify Environment Variables
4. Done!